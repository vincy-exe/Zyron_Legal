import aiosqlite

DB_PATH = "zyron.db"


async def add_whitelist(guild_id, target_id, target_type="user"):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            INSERT OR REPLACE INTO whitelist
            (guild_id, target_id, target_type)
            VALUES (?, ?, ?)
            """,
            (guild_id, target_id, target_type)
        )
        await db.commit()


async def remove_whitelist(guild_id, target_id, target_type="user"):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            DELETE FROM whitelist
            WHERE guild_id = ?
            AND target_id = ?
            AND target_type = ?
            """,
            (guild_id, target_id, target_type)
        )
        await db.commit()


async def is_whitelisted(guild_id, target_id, target_type="user"):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            """
            SELECT 1 FROM whitelist
            WHERE guild_id = ?
            AND target_id = ?
            AND target_type = ?
            """,
            (guild_id, target_id, target_type)
        )

        return await cursor.fetchone() is not None
