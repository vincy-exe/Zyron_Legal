import aiosqlite

DB_PATH = "zyron.db"

async def init_protected_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS protected_members (
                guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                verified_at TEXT,
                PRIMARY KEY(guild_id,user_id)
            )
        """)
        await db.commit()

async def is_whitelisted(guild_id: int, user_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT 1 FROM whitelist WHERE guild_id=? AND user_id=?", (guild_id,user_id))
        return await cursor.fetchone() is not None

async def add_whitelist(guild_id: int, user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO whitelist(guild_id,user_id) VALUES(?,?)", (guild_id,user_id))
        await db.commit()

async def remove_whitelist(guild_id: int, user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM whitelist WHERE guild_id=? AND user_id=?", (guild_id,user_id))
        await db.commit()

async def get_whitelist(guild_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT user_id FROM whitelist WHERE guild_id=?", (guild_id,))
        return [row[0] for row in await cursor.fetchall()]

async def mark_protected(guild_id: int, user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO protected_members(guild_id,user_id,verified_at) VALUES(?,?,datetime('now'))",
            (guild_id,user_id)
        )
        await db.commit()

async def is_protected_member(guild_id: int, user_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT 1 FROM protected_members WHERE guild_id=? AND user_id=?", (guild_id,user_id))
        return await cur.fetchone() is not None

async def init_whitelist_entries_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""CREATE TABLE IF NOT EXISTS whitelist_entries (
            guild_id INTEGER NOT NULL, subject_type TEXT NOT NULL, subject_id INTEGER NOT NULL,
            action TEXT NOT NULL, PRIMARY KEY (guild_id, subject_type, subject_id, action))""")
        await db.commit()

async def add_whitelist_entry(guild_id, subject_type, subject_id, action):
    await init_whitelist_entries_db()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO whitelist_entries VALUES(?,?,?,?)",
                         (guild_id, subject_type, subject_id, action))
        await db.commit()

async def remove_whitelist_entry(guild_id, subject_id, action):
    await init_whitelist_entries_db()
    async with aiosqlite.connect(DB_PATH) as db:
        if action == "ALL":
            await db.execute("DELETE FROM whitelist_entries WHERE guild_id=? AND subject_id=?", (guild_id, subject_id))
        else:
            await db.execute("DELETE FROM whitelist_entries WHERE guild_id=? AND subject_id=? AND action=?",
                             (guild_id, subject_id, action))
        await db.commit()

async def get_whitelist_entries(guild_id):
    await init_whitelist_entries_db()
    async with aiosqlite.connect(DB_PATH) as db:
        cur=await db.execute("SELECT subject_type,subject_id,action FROM whitelist_entries WHERE guild_id=? ORDER BY subject_type,subject_id",
                             (guild_id,))
        rows=await cur.fetchall()
    return [{"subject_type":r[0],"subject_id":r[1],"action":r[2]} for r in rows]

async def is_action_whitelisted(guild, user_id, action):
    if guild.owner_id == user_id or await is_whitelisted(guild.id, user_id):
        return True
    member=guild.get_member(user_id)
    role_ids=[r.id for r in member.roles] if member else []
    await init_whitelist_entries_db()
    async with aiosqlite.connect(DB_PATH) as db:
        if role_ids:
            marks=",".join("?" for _ in role_ids)
            cur=await db.execute(f"""SELECT 1 FROM whitelist_entries
                WHERE guild_id=? AND action IN (?, 'ALL')
                AND ((subject_type='user' AND subject_id=?) OR (subject_type='role' AND subject_id IN ({marks}))) LIMIT 1""",
                (guild.id, action, user_id, *role_ids))
        else:
            cur=await db.execute("""SELECT 1 FROM whitelist_entries
                WHERE guild_id=? AND action IN (?, 'ALL') AND subject_type='user' AND subject_id=? LIMIT 1""",
                (guild.id, action, user_id))
        return await cur.fetchone() is not None
