import aiosqlite

DB_PATH = "zyron.db"

async def init_feedback_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS feedback_settings (
                guild_id INTEGER PRIMARY KEY,
                channel_id INTEGER
            )
        """)
        await db.commit()

async def set_feedback_channel(guild_id: int, channel_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO feedback_settings(guild_id,channel_id) VALUES(?,?) "
            "ON CONFLICT(guild_id) DO UPDATE SET channel_id=excluded.channel_id",
            (guild_id, channel_id)
        )
        await db.commit()

async def get_feedback_channel(guild_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT channel_id FROM feedback_settings WHERE guild_id=?", (guild_id,))
        row = await cur.fetchone()
        return row[0] if row else None
