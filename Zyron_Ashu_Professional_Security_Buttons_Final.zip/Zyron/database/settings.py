import aiosqlite

DB_PATH = "zyron.db"


async def get_settings(guild_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            """
            SELECT
                security_enabled,
                antinuke_enabled,
                antiraid_enabled,
                antispam_enabled,
                massban_enabled,
                log_channel_id
            FROM guild_settings
            WHERE guild_id = ?
            """,
            (guild_id,)
        )

        row = await cursor.fetchone()

        if row is None:
            return {
                "security_enabled": True,
                "antinuke_enabled": True,
                "antiraid_enabled": True,
                "antispam_enabled": True,
                "massban_enabled": True,
                "log_channel_id": None
            }

        return {
            "security_enabled": bool(row[0]),
            "antinuke_enabled": bool(row[1]),
            "antiraid_enabled": bool(row[2]),
            "antispam_enabled": bool(row[3]),
            "massban_enabled": bool(row[4]),
            "log_channel_id": row[5]
        }


async def set_setting(
    guild_id: int,
    setting: str,
    value: bool
):
    allowed = {
        "security_enabled",
        "antinuke_enabled",
        "antiraid_enabled",
        "antispam_enabled",
        "massban_enabled"
    }

    if setting not in allowed:
        raise ValueError("Invalid security setting")

    async with aiosqlite.connect(DB_PATH) as db:

        await db.execute(
            f"""
            UPDATE guild_settings
            SET {setting} = ?
            WHERE guild_id = ?
            """,
            (int(value), guild_id)
        )

        await db.commit()


async def set_log_channel(
    guild_id: int,
    channel_id: int
):
    async with aiosqlite.connect(DB_PATH) as db:

        await db.execute(
            """
            UPDATE guild_settings
            SET log_channel_id = ?
            WHERE guild_id = ?
            """,
            (channel_id, guild_id)
        )

        await db.commit()


async def enable_all_security(guild_id: int):
    """Enable the complete Zyron protection baseline for a guild."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            INSERT OR IGNORE INTO guild_settings (
                guild_id, security_enabled, antinuke_enabled,
                antiraid_enabled, antispam_enabled, massban_enabled
            ) VALUES (?, 1, 1, 1, 1, 1)
            """,
            (guild_id,)
        )
        await db.execute(
            """
            UPDATE guild_settings
            SET security_enabled = 1,
                antinuke_enabled = 1,
                antiraid_enabled = 1,
                antispam_enabled = 1,
                massban_enabled = 1
            WHERE guild_id = ?
            """,
            (guild_id,)
        )
        await db.commit()
