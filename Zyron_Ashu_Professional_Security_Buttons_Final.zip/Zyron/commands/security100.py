import discord
from discord import app_commands
from discord.ext import commands

from database.protected import get_whitelist
from database.settings import get_settings, set_setting
from core.security_log import security_log
from security.lockdown import lockdown
from security.backup import create_backup


MODULES = {
    "security": "security_enabled",
    "antinuke": "antinuke_enabled",
    "antiraid": "antiraid_enabled",
    "antispam": "antispam_enabled",
    "massban": "massban_enabled",
}


def state(value):
    return "🟢 ON" if value else "🔴 OFF"


def admin_only(command):
    return app_commands.checks.has_permissions(administrator=True)(command)


class Security100(commands.Cog):
    """100 practical security/admin commands grouped for Zyron."""

    def __init__(self, bot):
        self.bot = bot

    core = app_commands.Group(name="security-core", description="Core Zyron security controls")
    guards = app_commands.Group(name="security-guards", description="Guard and protection diagnostics")
    admin = app_commands.Group(name="security-tools", description="Advanced Zyron security administration")
    audit = app_commands.Group(name="security-audit", description="Security audit and server diagnostics")

    async def _status(self, interaction):
        settings = await get_settings(interaction.guild.id)
        embed = discord.Embed(title="🛡️ Zyron Security Status", color=discord.Color.blurple())
        for label, key in (
            ("Security", "security_enabled"),
            ("Anti-Nuke", "antinuke_enabled"),
            ("Anti-Raid", "antiraid_enabled"),
            ("Anti-Spam", "antispam_enabled"),
            ("Mass-Ban", "massban_enabled"),
        ):
            embed.add_field(name=label, value=state(settings[key]), inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    async def _toggle(self, interaction, module, enabled):
        await set_setting(interaction.guild.id, MODULES[module], enabled)
        await interaction.response.send_message(
            f"🛡️ **{module.title()}** protection → **{'ON' if enabled else 'OFF'}**",
            ephemeral=True,
        )

    async def _info(self, interaction, title, value):
        embed = discord.Embed(title=f"🛡️ {title}", description=value, color=discord.Color.blurple())
        embed.set_footer(text="Zyron Security • Developed by - Ashu")
        await interaction.response.send_message(embed=embed, ephemeral=True)


# 25 Core commands
CORE_DEFS = [
    ("status", "Show all security module states", "status"),
    ("enable", "Enable the main security system", "enable_security"),
    ("disable", "Disable the main security system", "disable_security"),
    ("antinuke-on", "Enable Anti-Nuke", "antinuke_on"),
    ("antinuke-off", "Disable Anti-Nuke", "antinuke_off"),
    ("antiraid-on", "Enable Anti-Raid", "antiraid_on"),
    ("antiraid-off", "Disable Anti-Raid", "antiraid_off"),
    ("antispam-on", "Enable Anti-Spam", "antispam_on"),
    ("antispam-off", "Disable Anti-Spam", "antispam_off"),
    ("massban-on", "Enable Mass-Ban protection", "massban_on"),
    ("massban-off", "Disable Mass-Ban protection", "massban_off"),
    ("health", "Check Zyron security health", "health"),
    ("latency", "Check Zyron latency", "latency"),
    ("guild-id", "Show the current server ID", "guild_id"),
    ("owner", "Show the current server owner", "owner"),
    ("member-count", "Show member count", "member_count"),
    ("bot-count", "Show bot count", "bot_count"),
    ("role-count", "Show role count", "role_count"),
    ("channel-count", "Show channel count", "channel_count"),
    ("text-channel-count", "Show text channel count", "text_channel_count"),
    ("voice-channel-count", "Show voice channel count", "voice_channel_count"),
    ("category-count", "Show category count", "category_count"),
    ("verification", "Show server verification level", "verification"),
    ("features", "Show server security-related features", "features"),
    ("permissions", "Check Zyron permissions", "permissions"),
]

async def core_callback(self, interaction, action):
    if action in {"status", "health", "latency", "guild_id", "owner", "member_count", "bot_count", "role_count", "channel_count", "text_channel_count", "voice_channel_count", "category_count", "verification", "features", "permissions"}:
        return await self._status_or_info(interaction, action)
    if not interaction.user.guild_permissions.administrator:
        return await interaction.response.send_message("❌ Administrator permission required.", ephemeral=True)
    mapping = {
        "enable_security": ("security", True), "disable_security": ("security", False),
        "antinuke_on": ("antinuke", True), "antinuke_off": ("antinuke", False),
        "antiraid_on": ("antiraid", True), "antiraid_off": ("antiraid", False),
        "antispam_on": ("antispam", True), "antispam_off": ("antispam", False),
        "massban_on": ("massban", True), "massban_off": ("massban", False),
    }
    module, enabled = mapping[action]
    return await self._toggle(interaction, module, enabled)

async def _status_or_info(self, interaction, action):
    if action == "status": return await self._status(interaction)
    if action == "health": return await self._info(interaction, "Security Health", "🟢 Zyron security engine is responding.")
    if action == "latency": return await self._info(interaction, "Bot Latency", f"`{round(self.bot.latency * 1000)}ms`")
    g = interaction.guild
    values = {
        "guild_id": ("Server ID", f"`{g.id}`"), "owner": ("Server Owner", f"<@{g.owner_id}>"),
        "member_count": ("Members", f"`{g.member_count}`"), "bot_count": ("Bots", f"`{sum(1 for m in g.members if m.bot)}`"),
        "role_count": ("Roles", f"`{len(g.roles)}`"), "channel_count": ("Channels", f"`{len(g.channels)}`"),
        "text_channel_count": ("Text Channels", f"`{len(g.text_channels)}`"), "voice_channel_count": ("Voice Channels", f"`{len(g.voice_channels)}`"),
        "category_count": ("Categories", f"`{len(g.categories)}`"), "verification": ("Verification Level", f"`{g.verification_level}`"),
        "features": ("Guild Features", "\n".join(f"• `{x}`" for x in g.features) or "None"),
    }
    if action == "permissions":
        return await self._info(interaction, "Zyron Permissions", "\n".join(f"• {name}: {'✅' if value else '❌'}" for name, value in {"Ban Members": g.me.guild_permissions.ban_members, "Kick Members": g.me.guild_permissions.kick_members, "Manage Channels": g.me.guild_permissions.manage_channels, "Manage Roles": g.me.guild_permissions.manage_roles, "Manage Webhooks": g.me.guild_permissions.manage_webhooks, "View Audit Log": g.me.guild_permissions.view_audit_log}.items()))
    title, value = values[action]
    return await self._info(interaction, title, value)

Security100._status_or_info = _status_or_info
Security100.core_callback = core_callback

# 25 Guard commands
GUARD_DEFS = [
    ("antinuke-status", "Show Anti-Nuke status"), ("raid-status", "Show Anti-Raid status"),
    ("spam-status", "Show Anti-Spam status"), ("massban-status", "Show Mass-Ban status"),
    ("dangerous-roles", "List roles with dangerous permissions"), ("admin-roles", "List Administrator roles"),
    ("manage-role-roles", "List roles with Manage Roles"), ("manage-channel-roles", "List roles with Manage Channels"),
    ("ban-roles", "List roles with Ban Members"), ("kick-roles", "List roles with Kick Members"),
    ("webhook-roles", "List roles with Manage Webhooks"), ("everyone-perms", "Show @everyone permissions"),
    ("bot-hierarchy", "Show Zyron's highest role"), ("owner-hierarchy", "Show owner role position"),
    ("whitelist-count", "Show whitelist size"), ("whitelist-check", "Check whether a user is whitelisted"),
    ("log-channel", "Show configured security log channel"), ("audit-check", "Check audit-log access"),
    ("lockdown-ready", "Check whether Zyron can lockdown channels"), ("backup-ready", "Check backup capability"),
    ("member-intent", "Check member intent state"), ("message-intent", "Check message intent state"),
    ("guild-intent", "Check guild intent state"), ("security-modules", "List enabled security modules"),
    ("guard-summary", "Show a guard summary"),
]

async def guard_callback(self, interaction, action):
    g = interaction.guild
    settings = await get_settings(g.id)
    if action.endswith("status"):
        key = {"antinuke-status":"antinuke_enabled", "raid-status":"antiraid_enabled", "spam-status":"antispam_enabled", "massban-status":"massban_enabled"}[action]
        return await self._info(interaction, action.replace("-", " ").title(), state(settings[key]))
    if action == "dangerous-roles":
        roles = [r.mention for r in g.roles if any([r.permissions.administrator, r.permissions.manage_guild, r.permissions.manage_roles, r.permissions.manage_channels, r.permissions.ban_members, r.permissions.kick_members, r.permissions.manage_webhooks])]
        return await self._info(interaction, "Dangerous Roles", "\n".join(roles) or "None")
    perms = {
        "admin-roles": lambda r: r.permissions.administrator,
        "manage-role-roles": lambda r: r.permissions.manage_roles,
        "manage-channel-roles": lambda r: r.permissions.manage_channels,
        "ban-roles": lambda r: r.permissions.ban_members,
        "kick-roles": lambda r: r.permissions.kick_members,
        "webhook-roles": lambda r: r.permissions.manage_webhooks,
    }
    if action in perms:
        roles = [r.mention for r in g.roles if perms[action](r)]
        return await self._info(interaction, action.replace("-", " ").title(), "\n".join(roles) or "None")
    if action == "everyone-perms":
        p = g.default_role.permissions
        return await self._info(interaction, "@everyone Permissions", f"Administrator: `{p.administrator}`\nManage Guild: `{p.manage_guild}`\nManage Roles: `{p.manage_roles}`\nManage Channels: `{p.manage_channels}`")
    if action == "bot-hierarchy": return await self._info(interaction, "Zyron Hierarchy", f"Highest role: {g.me.top_role.mention}\nPosition: `{g.me.top_role.position}`")
    if action == "owner-hierarchy": return await self._info(interaction, "Owner", f"<@{g.owner_id}>")
    if action == "whitelist-count": return await self._info(interaction, "Whitelist", f"`{len(await get_whitelist(g.id))}` user(s)")
    if action == "log-channel": return await self._info(interaction, "Security Log", f"<#{settings['log_channel_id']}>" if settings["log_channel_id"] else "Not configured")
    if action == "security-modules": return await self._info(interaction, "Security Modules", "\n".join(f"• {k}: {state(settings[v])}" for k,v in MODULES.items()))
    if action == "guard-summary": return await self._status(interaction)
    if action == "audit-check": return await self._info(interaction, "Audit Log", "✅ Permission is available." if g.me.guild_permissions.view_audit_log else "❌ View Audit Log is missing.")
    if action == "lockdown-ready": return await self._info(interaction, "Lockdown Ready", "✅ Manage Channels available." if g.me.guild_permissions.manage_channels else "❌ Manage Channels missing.")
    if action == "backup-ready": return await self._info(interaction, "Backup Ready", "✅ Zyron can read the current server structure.")
    if action == "member-intent": return await self._info(interaction, "Member Intent", "✅ Enabled" if self.bot.intents.members else "❌ Disabled")
    if action == "message-intent": return await self._info(interaction, "Message Intent", "✅ Enabled" if self.bot.intents.message_content else "❌ Disabled")
    if action == "guild-intent": return await self._info(interaction, "Guild Intent", "✅ Enabled" if self.bot.intents.guilds else "❌ Disabled")
    if action == "whitelist-check": return await self._info(interaction, "Whitelist Check", "Use `/whitelist list` for the current trusted users.")


# 25 Admin commands
ADMIN_DEFS = [
    ("lockdown", "Lock text channels"), ("backup", "Create a server structure backup"),
    ("security-log-test", "Send a test security log"), ("security-log-on", "Show whether logs are configured"),
    ("security-reset", "Restore all security modules to ON"), ("antinuke-reset", "Enable Anti-Nuke"),
    ("antiraid-reset", "Enable Anti-Raid"), ("antispam-reset", "Enable Anti-Spam"),
    ("massban-reset", "Enable Mass-Ban"), ("module-summary", "Show module summary"),
    ("channel-summary", "Show channel summary"), ("role-summary", "Show role summary"),
    ("member-summary", "Show member summary"), ("bot-summary", "Show bot summary"),
    ("security-permissions", "Show required security permissions"), ("hierarchy-check", "Check role hierarchy"),
    ("audit-permission", "Check audit-log permission"), ("ban-permission", "Check ban permission"),
    ("kick-permission", "Check kick permission"), ("role-permission", "Check role permission"),
    ("channel-permission", "Check channel permission"), ("webhook-permission", "Check webhook permission"),
    ("lockdown-permission", "Check lockdown permission"), ("backup-now", "Create a backup now"),
    ("admin-help", "Show security administrator tools"),
]

async def admin_callback(self, interaction, action):
    if not interaction.user.guild_permissions.administrator:
        return await interaction.response.send_message("❌ Administrator permission required.", ephemeral=True)
    g = interaction.guild
    if action == "lockdown":
        await interaction.response.defer(ephemeral=True)
        changed = await lockdown(g, "Manual Zyron security lockdown")
        return await interaction.followup.send(f"🔒 Lockdown enabled for `{changed}` channel(s).", ephemeral=True)
    if action in {"backup", "backup-now"}:
        path = await create_backup(g)
        return await interaction.response.send_message(f"💾 Backup created: `{path}`", ephemeral=True)
    if action == "security-log-test":
        await security_log(g, "🧪 Test Security Log", "This is a Zyron security log test.")
        return await interaction.response.send_message("📋 Test log sent.", ephemeral=True)
    if action == "security-reset":
        for module in MODULES.values(): await set_setting(g.id, module, True)
        return await interaction.response.send_message("🛡️ All security modules enabled.", ephemeral=True)
    if action.endswith("-reset"):
        module = action.split("-")[0]
        if module in MODULES:
            await set_setting(g.id, MODULES[module], True)
            return await interaction.response.send_message(f"🟢 {module.title()} enabled.", ephemeral=True)
    if action == "module-summary": return await self._status(interaction)
    if action == "channel-summary": return await self._info(interaction, "Channel Summary", f"Text: `{len(g.text_channels)}`\nVoice: `{len(g.voice_channels)}`\nCategories: `{len(g.categories)}`")
    if action == "role-summary": return await self._info(interaction, "Role Summary", f"Total roles: `{len(g.roles)}`\nHighest: {g.roles[-1].mention}")
    if action == "member-summary": return await self._info(interaction, "Member Summary", f"Members: `{g.member_count}`")
    if action == "bot-summary": return await self._info(interaction, "Bot Summary", f"Bots: `{sum(1 for m in g.members if m.bot)}`")
    checks = {
        "audit-permission": ("View Audit Log", g.me.guild_permissions.view_audit_log),
        "ban-permission": ("Ban Members", g.me.guild_permissions.ban_members),
        "kick-permission": ("Kick Members", g.me.guild_permissions.kick_members),
        "role-permission": ("Manage Roles", g.me.guild_permissions.manage_roles),
        "channel-permission": ("Manage Channels", g.me.guild_permissions.manage_channels),
        "webhook-permission": ("Manage Webhooks", g.me.guild_permissions.manage_webhooks),
        "lockdown-permission": ("Manage Channels", g.me.guild_permissions.manage_channels),
    }
    if action in checks:
        name, ok = checks[action]; return await self._info(interaction, name, "✅ Available" if ok else "❌ Missing")
    if action == "security-permissions": return await self._info(interaction, "Required Permissions", "View Audit Log • Ban Members • Kick Members • Manage Roles • Manage Channels • Manage Webhooks")
    if action == "hierarchy-check": return await self._info(interaction, "Hierarchy Check", "✅ Zyron has a role above manageable members." if g.me.top_role.position > 0 else "❌ Move Zyron's role higher.")
    if action == "admin-help": return await self._info(interaction, "Security Admin", "Use the `/security-admin` command group for advanced tools.")
    if action == "security-log-on":
        settings = await get_settings(g.id); return await self._info(interaction, "Security Logs", "🟢 Configured" if settings["log_channel_id"] else "🔴 Not configured")


# 25 Audit commands
AUDIT_DEFS = [
    ("overview", "Show a complete security overview"), ("server-name", "Show server name"),
    ("server-created", "Show server creation time"), ("server-owner", "Show server owner"),
    ("server-region", "Show server locale"), ("server-boost", "Show boost information"),
    ("server-level", "Show server verification level"), ("server-afk", "Show AFK settings"),
    ("server-system", "Show system channel"), ("server-rules", "Show rules channel"),
    ("server-public", "Show public status"), ("server-community", "Show community status"),
    ("server-discovery", "Show discovery status"), ("server-partner", "Show partner status"),
    ("server-vanity", "Show vanity URL code"), ("security-owner", "Show security owner"),
    ("security-role", "Show Zyron role"), ("security-position", "Show Zyron role position"),
    ("security-channel", "Show current command channel"), ("security-user", "Show requesting user"),
    ("security-time", "Show current security check time"), ("security-version", "Show Zyron security version"),
    ("security-brand", "Show Zyron security branding"), ("security-credit", "Show development credit"),
    ("audit-summary", "Show audit readiness summary"),
]

async def audit_callback(self, interaction, action):
    g = interaction.guild
    if action == "overview": return await self._status(interaction)
    if action == "server-name": return await self._info(interaction, "Server Name", g.name)
    if action == "server-created": return await self._info(interaction, "Server Created", discord.utils.format_dt(g.created_at, "F"))
    if action == "server-owner": return await self._info(interaction, "Server Owner", f"<@{g.owner_id}>")
    if action == "server-region": return await self._info(interaction, "Server Locale", str(g.preferred_locale))
    if action == "server-boost": return await self._info(interaction, "Boosts", f"Level: `{g.premium_tier}`\nBoosts: `{g.premium_subscription_count}`")
    if action == "server-level": return await self._info(interaction, "Verification", str(g.verification_level))
    if action == "server-afk": return await self._info(interaction, "AFK", f"Channel: {g.afk_channel.mention if g.afk_channel else 'None'}\nTimeout: `{g.afk_timeout}s`")
    if action == "server-system": return await self._info(interaction, "System Channel", g.system_channel.mention if g.system_channel else "None")
    if action == "server-rules": return await self._info(interaction, "Rules Channel", g.rules_channel.mention if g.rules_channel else "None")
    if action == "server-public": return await self._info(interaction, "Public", "Yes" if g.public_updates_channel else "No")
    if action == "server-community": return await self._info(interaction, "Community", "Yes" if 'COMMUNITY' in g.features else "No")
    if action == "server-discovery": return await self._info(interaction, "Discovery", "Yes" if 'DISCOVERABLE' in g.features else "No")
    if action == "server-partner": return await self._info(interaction, "Partnered", "Yes" if 'PARTNERED' in g.features else "No")
    if action == "server-vanity": return await self._info(interaction, "Vanity", g.vanity_url_code or "None")
    if action == "security-owner": return await self._info(interaction, "Security Owner", f"<@{g.owner_id}>")
    if action == "security-role": return await self._info(interaction, "Zyron Role", g.me.top_role.mention)
    if action == "security-position": return await self._info(interaction, "Zyron Position", f"`{g.me.top_role.position}`")
    if action == "security-channel": return await self._info(interaction, "Command Channel", interaction.channel.mention if interaction.channel else "Unknown")
    if action == "security-user": return await self._info(interaction, "Requester", interaction.user.mention)
    if action == "security-time": return await self._info(interaction, "Security Time", discord.utils.format_dt(discord.utils.utcnow(), "F"))
    if action == "security-version": return await self._info(interaction, "Security Version", "Zyron Security 1.0")
    if action == "security-brand": return await self._info(interaction, "Brand", "🛡️ Zyron Security")
    if action == "security-credit": return await self._info(interaction, "Development", "Developed by - Ashu")
    if action == "audit-summary":
        p = g.me.guild_permissions
        return await self._info(interaction, "Audit Summary", f"View Audit Log: {'✅' if p.view_audit_log else '❌'}\nBan: {'✅' if p.ban_members else '❌'}\nKick: {'✅' if p.kick_members else '❌'}\nManage Roles: {'✅' if p.manage_roles else '❌'}\nManage Channels: {'✅' if p.manage_channels else '❌'}")


async def setup(bot):
    cog = Security100(bot)
    for name, desc, action in CORE_DEFS:
        async def cb(interaction, _action=action):
            return await core_callback(cog, interaction, _action)
        cog.core.add_command(app_commands.Command(name=name, description=desc, callback=cb))
    for name, desc in GUARD_DEFS:
        async def cb(interaction, _action=name):
            return await guard_callback(cog, interaction, _action)
        cog.guards.add_command(app_commands.Command(name=name, description=desc, callback=cb))
    for name, desc in ADMIN_DEFS:
        async def cb(interaction, _action=name):
            return await admin_callback(cog, interaction, _action)
        cog.admin.add_command(app_commands.Command(name=name, description=desc, callback=cb))
    for name, desc in AUDIT_DEFS:
        async def cb(interaction, _action=name):
            return await audit_callback(cog, interaction, _action)
        cog.audit.add_command(app_commands.Command(name=name, description=desc, callback=cb))
    await bot.add_cog(cog)
