import discord
from discord import app_commands
from discord.ext import commands

from security.lockdown import lockdown
from security.backup import create_backup


class SecurityAdmin(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    security = app_commands.Group(
        name="security-admin",
        description="Zyron administrator security tools"
    )

    @security.command(
        name="lockdown",
        description="Lock text channels for @everyone"
    )
    @app_commands.checks.has_permissions(
        administrator=True
    )
    async def lockdown_command(
        self,
        interaction: discord.Interaction
    ):

        await interaction.response.defer(
            ephemeral=True
        )

        changed = await lockdown(
            interaction.guild,
            "Manual Zyron security lockdown"
        )

        await interaction.followup.send(
            f"🔒 Lockdown enabled for `{changed}` channel(s).",
            ephemeral=True
        )

    @security.command(
        name="backup",
        description="Create an in-memory server structure backup"
    )
    @app_commands.checks.has_permissions(
        administrator=True
    )
    async def backup_command(
        self,
        interaction: discord.Interaction
    ):

        backup = await create_backup(
            interaction.guild
        )

        await interaction.response.send_message(
            (
                "💾 **Backup created**\n"
                f"Roles: `{len(backup['roles'])}`\n"
                f"Channels: `{len(backup['channels'])}`"
            ),
            ephemeral=True
        )


async def setup(bot):
    await bot.add_cog(
        SecurityAdmin(bot)
    )
