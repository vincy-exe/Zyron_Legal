import discord
from discord import app_commands
from discord.ext import commands

from database.protected import (
    add_whitelist,
    remove_whitelist,
    get_whitelist
)


class Whitelist(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    whitelist = app_commands.Group(
        name="whitelist",
        description="Manage Zyron trusted users"
    )

    @whitelist.command(
        name="add",
        description="Add a user to whitelist"
    )
    @app_commands.checks.has_permissions(
        administrator=True
    )
    async def add(
        self,
        interaction: discord.Interaction,
        user: discord.Member
    ):

        if user.id == interaction.guild.owner_id:

            await interaction.response.send_message(
                "⚠️ Server owner is already trusted.",
                ephemeral=True
            )
            return

        await add_whitelist(
            interaction.guild.id,
            user.id
        )

        await interaction.response.send_message(
            f"✅ {user.mention} added to Zyron whitelist."
        )

    @whitelist.command(
        name="remove",
        description="Remove a user from whitelist"
    )
    @app_commands.checks.has_permissions(
        administrator=True
    )
    async def remove(
        self,
        interaction: discord.Interaction,
        user: discord.Member
    ):

        await remove_whitelist(
            interaction.guild.id,
            user.id
        )

        await interaction.response.send_message(
            f"✅ {user.mention} removed from whitelist."
        )

    @whitelist.command(
        name="list",
        description="Show whitelisted users"
    )
    @app_commands.checks.has_permissions(
        administrator=True
    )
    async def list(
        self,
        interaction: discord.Interaction
    ):

        users = await get_whitelist(
            interaction.guild.id
        )

        if not users:

            await interaction.response.send_message(
                "📋 Whitelist is empty."
            )
            return

        lines = []

        for user_id in users:

            member = interaction.guild.get_member(
                user_id
            )

            if member:
                lines.append(
                    f"• {member.mention} (`{user_id}`)"
                )
            else:
                lines.append(
                    f"• `<@{user_id}>` (`{user_id}`)"
                )

        await interaction.response.send_message(
            "🛡️ **Zyron Whitelist**\n\n"
            + "\n".join(lines)
        )


async def setup(bot):

    await bot.add_cog(
        Whitelist(bot)
    )
