import discord
from discord import app_commands
from discord.ext import commands
from database.settings import get_settings, enable_all_security, set_log_channel
from security.protected_role import get_or_create_protected_role

ACTIONS = ["ALL","BAN","KICK","CHANNEL_CREATE","CHANNEL_DELETE","ROLE_CREATE","ROLE_DELETE","WEBHOOK_CREATE","BOT_ADD","PERMISSION_CHANGE","MESSAGE_SPAM","LINK_SPAM","RAID"]

def embed(title, text=""):
    e=discord.Embed(title=title,description=text,color=discord.Color.blurple())
    e.set_author(name="Zyron Security • Developed by - Ashu")
    e.set_footer(text="Zyron Professional Security • Buttons")
    return e

def home_embed():
    return embed("🛡️ ZYRON SECURITY",
        "Choose a section below. **Everything is controlled with buttons.**\n\n"
        "🛡️ **SERVER SECURITY** — Enable all protection\n"
        "🛡️ **WHITELIST** — User/Role + specific protection\n"
        "📜 **LOGS SETUP** — One automatic security log channel")

async def setup_security(guild):
    await enable_all_security(guild.id)
    role=await get_or_create_protected_role(guild)
    ch=discord.utils.get(guild.text_channels,name="zyron-security-data")
    if ch is None:
        try: ch=await guild.create_text_channel("zyron-security-data",reason="Zyron Security logs")
        except (discord.Forbidden,discord.HTTPException): ch=None
    if ch:
        try: await set_log_channel(guild.id,ch.id)
        except Exception: pass
    return role,ch

async def enabled(guild):
    s=await get_settings(guild.id)
    return all(s.get(k,False) for k in ("security_enabled","antinuke_enabled","antiraid_enabled","antispam_enabled","massban_enabled"))

class HomeView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=600)
        self.add_item(PageButton("Previous","◀️",0,-1))
        self.add_item(PageButton("SERVER SECURITY","🛡️",0,0))
        self.add_item(PageButton("WHITELIST","🛡️",0,1))
        self.add_item(PageButton("LOGS SETUP","📜",0,2))
        self.add_item(PageButton("Next","▶️",0,1))

class PageButton(discord.ui.Button):
    def __init__(self,label,emoji,current,delta_or_target):
        style=discord.ButtonStyle.primary if label in ("SERVER SECURITY","WHITELIST","LOGS SETUP") else discord.ButtonStyle.secondary
        super().__init__(label=label,emoji=emoji,style=style)
        self.current=current
        self.delta_or_target=delta_or_target
    async def callback(self,i):
        target = self.delta_or_target if self.label in ("SERVER SECURITY","WHITELIST","LOGS SETUP") else (self.current + self.delta_or_target) % 3
        views=[(await security_embed(i.guild),SecurityView(target)),(whitelist_embed(),WhitelistView(target)),(logs_embed(),LogsView(target))]
        await i.response.edit_message(embed=views[target][0],view=views[target][1])

class BackHome(discord.ui.Button):
    def __init__(self): super().__init__(label="HOME",emoji="🏠",style=discord.ButtonStyle.secondary)
    async def callback(self,i): await i.response.edit_message(embed=home_embed(),view=HomeView())

async def security_embed(guild):
    return embed("🛡️ SERVER SECURITY",
        f"**Status:** {'🟢 ENABLED' if await enabled(guild) else '🔴 NOT ENABLED'}\n\n"
        "**ENABLE ALL SECURITY** activates:\n"
        "• Anti-Nuke • Anti-Raid • Anti-Spam • Anti-Link Spam\n"
        "• Anti-Role Create/Delete • Anti-Channel Create/Delete\n"
        "• Dangerous Permission Guard • Anti-Webhook Create • Anti-Bot Add\n"
        "• Unauthorized destructive actions → **Instant Ban**\n\n"
        "**Automatic setup:** `Zyron Protected` role + `#zyron-security-data`.")

class SecurityView(discord.ui.View):
    def __init__(self,page=0):
        super().__init__(timeout=600)
        self.add_item(EnableAll()); self.add_item(PageButton("Previous","◀️",page,-1)); self.add_item(BackHome()); self.add_item(PageButton("Next","▶️",page,1))

class EnableAll(discord.ui.Button):
    def __init__(self): super().__init__(label="ENABLE ALL SECURITY",emoji="🛡️",style=discord.ButtonStyle.success)
    async def callback(self,i):
        if not i.user.guild_permissions.manage_guild: return await i.response.send_message("❌ Manage Server permission required.",ephemeral=True)
        role,ch=await setup_security(i.guild)
        lines=["🟢 All security modules enabled","🔨 Punishment: Instant Ban"]
        lines.append("👑 `Zyron Protected` role ready" if role else "⚠️ Protected role creation failed")
        lines.append(f"📜 {ch.mention} ready" if ch else "⚠️ Log channel creation failed")
        await i.response.edit_message(embed=embed("🟢 SERVER SECURITY ENABLED","\n".join(lines)),view=SecurityView())

def whitelist_embed():
    return embed("🛡️ WHITELIST",
        "Add **users or roles** for a specific protection.\n\n"
        "**Protection values:** `ALL`, `BAN`, `KICK`, `CHANNEL_CREATE`, `CHANNEL_DELETE`, "
        "`ROLE_CREATE`, `ROLE_DELETE`, `WEBHOOK_CREATE`, `BOT_ADD`, `PERMISSION_CHANGE`, "
        "`MESSAGE_SPAM`, `LINK_SPAM`, `RAID`")

class WhitelistView(discord.ui.View):
    def __init__(self,page=1):
        super().__init__(timeout=600)
        self.add_item(AddUser()); self.add_item(AddRole()); self.add_item(Remove()); self.add_item(ListEntries()); self.add_item(PageButton("Previous","◀️",page,-1)); self.add_item(BackHome()); self.add_item(PageButton("Next","▶️",page,1))

class AddUser(discord.ui.Button):
    def __init__(self): super().__init__(label="ADD USER",emoji="👤",style=discord.ButtonStyle.success)
    async def callback(self,i):
        if not i.user.guild_permissions.manage_guild:return await i.response.send_message("❌ Manage Server permission required.",ephemeral=True)
        await i.response.send_modal(AddModal("user"))

class AddRole(discord.ui.Button):
    def __init__(self): super().__init__(label="ADD ROLE",emoji="🎭",style=discord.ButtonStyle.success)
    async def callback(self,i):
        if not i.user.guild_permissions.manage_guild:return await i.response.send_message("❌ Manage Server permission required.",ephemeral=True)
        await i.response.send_modal(AddModal("role"))

class Remove(discord.ui.Button):
    def __init__(self): super().__init__(label="REMOVE",emoji="➖",style=discord.ButtonStyle.danger)
    async def callback(self,i):
        if not i.user.guild_permissions.manage_guild:return await i.response.send_message("❌ Manage Server permission required.",ephemeral=True)
        await i.response.send_modal(RemoveModal())

class ListEntries(discord.ui.Button):
    def __init__(self): super().__init__(label="LIST",emoji="📋",style=discord.ButtonStyle.primary)
    async def callback(self,i):
        from database.protected import get_whitelist_entries
        rows=await get_whitelist_entries(i.guild.id)
        out=[]
        for r in rows[:50]:
            obj=i.guild.get_member(r["subject_id"]) if r["subject_type"]=="user" else i.guild.get_role(r["subject_id"])
            out.append(f"• {obj.mention if obj else '`'+str(r['subject_id'])+'`'} → `{r['action']}`")
        await i.response.send_message(embed=embed("📋 WHITELIST LIST","\n".join(out) if out else "Whitelist is empty."),ephemeral=True)

class AddModal(discord.ui.Modal):
    def __init__(self,kind):
        self.kind=kind; super().__init__(title=f"Add {kind.title()} Whitelist")
        self.sid=discord.ui.TextInput(label=f"{kind.title()} ID",placeholder="Discord ID",required=True)
        self.action=discord.ui.TextInput(label="Protection",placeholder="BAN / KICK / CHANNEL_CREATE / ALL",required=True)
        self.add_item(self.sid); self.add_item(self.action)
    async def on_submit(self,i):
        try: sid=int(str(self.sid.value).strip())
        except ValueError:return await i.response.send_message("❌ Invalid ID.",ephemeral=True)
        action=str(self.action.value).strip().upper()
        if action not in ACTIONS:return await i.response.send_message("❌ Invalid protection.",ephemeral=True)
        if self.kind=="user" and i.guild.get_member(sid) is None:return await i.response.send_message("❌ User is not in this server.",ephemeral=True)
        if self.kind=="role" and i.guild.get_role(sid) is None:return await i.response.send_message("❌ Role is not in this server.",ephemeral=True)
        from database.protected import add_whitelist_entry
        await add_whitelist_entry(i.guild.id,self.kind,sid,action)
        await i.response.send_message(f"✅ {self.kind.title()} whitelisted for `{action}`.",ephemeral=True)

class RemoveModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title="Remove Whitelist")
        self.sid=discord.ui.TextInput(label="User/Role ID",placeholder="Discord ID",required=True)
        self.action=discord.ui.TextInput(label="Protection",placeholder="BAN / KICK / ALL",required=True)
        self.add_item(self.sid);self.add_item(self.action)
    async def on_submit(self,i):
        try:sid=int(str(self.sid.value).strip())
        except ValueError:return await i.response.send_message("❌ Invalid ID.",ephemeral=True)
        from database.protected import remove_whitelist_entry
        await remove_whitelist_entry(i.guild.id,sid,str(self.action.value).strip().upper())
        await i.response.send_message("✅ Whitelist entry removed.",ephemeral=True)

def logs_embed():
    return embed("📜 LOGS SETUP","**Single channel:** `#zyron-security-data`\n\nPress **SETUP LOGS**. Zyron creates it automatically if needed and saves it as the server security log channel.")

class LogsView(discord.ui.View):
    def __init__(self,page=2):
        super().__init__(timeout=600);self.add_item(SetupLogs());self.add_item(PageButton("Previous","◀️",page,-1));self.add_item(BackHome());self.add_item(PageButton("Next","▶️",page,1))

class SetupLogs(discord.ui.Button):
    def __init__(self):super().__init__(label="SETUP LOGS",emoji="📜",style=discord.ButtonStyle.success)
    async def callback(self,i):
        if not i.user.guild_permissions.manage_guild:return await i.response.send_message("❌ Manage Server permission required.",ephemeral=True)
        _,ch=await setup_security(i.guild)
        await i.response.edit_message(embed=embed("📜 LOGS READY" if ch else "⚠️ LOG SETUP FAILED",f"All security logs → {ch.mention}" if ch else "Zyron needs Manage Channels permission."),view=LogsView())

class HelpCog(commands.Cog):
    def __init__(self,bot):self.bot=bot
    @app_commands.command(name="help",description="Open Zyron Security button dashboard")
    async def help(self,i): i.message=None; await i.response.send_message(embed=home_embed(),view=HomeView(),ephemeral=True)

async def setup(bot): await bot.add_cog(HelpCog(bot))
