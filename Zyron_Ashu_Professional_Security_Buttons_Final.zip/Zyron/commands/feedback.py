import discord
from discord import app_commands
from discord.ext import commands
from database.feedback import set_feedback_channel

class Feedback(commands.Cog):
    def __init__(self, bot):
        self.bot=bot

    feedback = app_commands.Group(name="feedback", description="Configure Zyron feedback")

    @feedback.command(name="set-channel", description="Set the channel where Zyron feedback is received")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def set_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        await set_feedback_channel(interaction.guild.id, channel.id)
        await interaction.response.send_message(f"✅ Feedback channel set to {channel.mention}.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Feedback(bot))
