import discord
from discord import app_commands
from discord.ext import commands

from security.protected_role import protect_member


class Protection(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    protection = app_commands.Group(
        name="protection",
        description="Manage protected members"
    )

    @protection.command(
        name="add",
        description="Protect a member from automated security actions"
    )
    @app_commands.checks.has_permissions(
        administrator=True
    )
    async def add(
        self,
        interaction: discord.Interaction,
        member: discord.Member
    ):

        if member.id == interaction.guild.owner_id:
            await interaction.response.send_message(
                "⚠️ Server owner is already protected.",
                ephemeral=True
            )
            return

        success = await protect_member(member)

        if success:
            await interaction.response.send_message(
                f"🛡️ {member.mention} is now protected."
            )
        else:
            await interaction.response.send_message(
                "❌ I couldn't assign the protected role. "
                "Check my Manage Roles permission and role hierarchy.",
                ephemeral=True
            )


async def setup(bot):
    await bot.add_cog(
        Protection(bot)
    )
