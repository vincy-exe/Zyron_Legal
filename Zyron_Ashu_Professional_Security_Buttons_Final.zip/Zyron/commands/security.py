import discord
from discord import app_commands

from database.settings import (
    get_settings,
    set_setting,
    set_log_channel
)


async def setup(bot):

    security_group = app_commands.Group(
        name="security",
        description="Zyron security controls"
    )

    @security_group.command(
        name="status",
        description="Show security status"
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def status(
        interaction: discord.Interaction
    ):

        settings = await get_settings(
            interaction.guild.id
        )

        embed = discord.Embed(
            title="🛡️ Zyron Security",
            description="Current server protection status"
        )

        embed.add_field(
            name="Security",
            value="🟢 ON" if settings["security_enabled"] else "🔴 OFF",
            inline=True
        )

        embed.add_field(
            name="Anti-Nuke",
            value="🟢 ON" if settings["antinuke_enabled"] else "🔴 OFF",
            inline=True
        )

        embed.add_field(
            name="Anti-Raid",
            value="🟢 ON" if settings["antiraid_enabled"] else "🔴 OFF",
            inline=True
        )

        embed.add_field(
            name="Anti-Spam",
            value="🟢 ON" if settings["antispam_enabled"] else "🔴 OFF",
            inline=True
        )

        embed.add_field(
            name="Mass-Ban",
            value="🟢 ON" if settings["massban_enabled"] else "🔴 OFF",
            inline=True
        )

        await interaction.response.send_message(
            embed=embed
        )


    @security_group.command(
        name="set",
        description="Enable or disable a security module"
    )
    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.describe(
        module="Security module",
        enabled="Enable or disable"
    )
    @app_commands.choices(
        module=[
            app_commands.Choice(
                name="Security",
                value="security_enabled"
            ),
            app_commands.Choice(
                name="Anti-Nuke",
                value="antinuke_enabled"
            ),
            app_commands.Choice(
                name="Anti-Raid",
                value="antiraid_enabled"
            ),
            app_commands.Choice(
                name="Anti-Spam",
                value="antispam_enabled"
            ),
            app_commands.Choice(
                name="Mass-Ban",
                value="massban_enabled"
            )
        ]
    )
    async def set_security(
        interaction: discord.Interaction,
        module: app_commands.Choice[str],
        enabled: bool
    ):

        await set_setting(
            interaction.guild.id,
            module.value,
            enabled
        )

        state = "enabled" if enabled else "disabled"

        await interaction.response.send_message(
            f"🛡️ **{module.name}** has been **{state}**."
        )


    @security_group.command(
        name="logchannel",
        description="Set Zyron security log channel"
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def logchannel(
        interaction: discord.Interaction,
        channel: discord.TextChannel
    ):

        await set_log_channel(
            interaction.guild.id,
            channel.id
        )

        await interaction.response.send_message(
            f"📋 Security logs set to {channel.mention}"
        )


    await bot.add_cog(
        SecurityCog(bot)
    ) if False else None

    bot.tree.add_command(
        security_group
    )
