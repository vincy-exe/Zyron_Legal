import discord
from discord import app_commands
from discord.ext import commands

import aiosqlite

DB_PATH = "zyron.db"


class SecurityLogs(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    logs = app_commands.Group(
        name="security-logs",
        description="Configure Zyron security logs"
    )

    @logs.command(
        name="set",
        description="Set the security log channel"
    )
    @app_commands.checks.has_permissions(
        administrator=True
    )
    async def set_log(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel
    ):

        async with aiosqlite.connect(DB_PATH) as db:

            await db.execute(
                """
                UPDATE guild_settings
                SET log_channel_id = ?
                WHERE guild_id = ?
                """,
                (
                    channel.id,
                    interaction.guild.id
                )
            )

            await db.commit()

        await interaction.response.send_message(
            f"✅ Security logs set to {channel.mention}.",
            ephemeral=True
        )

    @logs.command(
        name="disable",
        description="Disable security logs"
    )
    @app_commands.checks.has_permissions(
        administrator=True
    )
    async def disable_log(
        self,
        interaction: discord.Interaction
    ):

        async with aiosqlite.connect(DB_PATH) as db:

            await db.execute(
                """
                UPDATE guild_settings
                SET log_channel_id = NULL
                WHERE guild_id = ?
                """,
                (interaction.guild.id,)
            )

            await db.commit()

        await interaction.response.send_message(
            "✅ Security logs disabled.",
            ephemeral=True
        )


async def setup(bot):
    await bot.add_cog(
        SecurityLogs(bot)
    )
