import discord
from discord import app_commands
from discord.ext import commands

from security.config import (
    get_setting,
    set_setting,
)


class SecurityStatus(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    security = app_commands.Group(
        name="security-settings",
        description="Configure Zyron security"
    )

    @security.command(
        name="status",
        description="Show Zyron security status"
    )
    @app_commands.checks.has_permissions(
        administrator=True
    )
    async def status(
        self,
        interaction: discord.Interaction
    ):

        guild_id = interaction.guild.id

        security = await get_setting(
            guild_id,
            "security_enabled"
        )

        antinuke = await get_setting(
            guild_id,
            "antinuke_enabled"
        )

        antiraid = await get_setting(
            guild_id,
            "antiraid_enabled"
        )

        antispam = await get_setting(
            guild_id,
            "antispam_enabled"
        )

        massban = await get_setting(
            guild_id,
            "massban_enabled"
        )

        def state(value):
            return "🟢 ON" if value else "🔴 OFF"

        embed = discord.Embed(
            title="🛡️ Zyron Security Status",
            color=discord.Color.dark_red()
        )

        embed.add_field(
            name="Security",
            value=state(security)
        )

        embed.add_field(
            name="Anti-Nuke",
            value=state(antinuke)
        )

        embed.add_field(
            name="Anti-Raid",
            value=state(antiraid)
        )

        embed.add_field(
            name="Anti-Spam",
            value=state(antispam)
        )

        embed.add_field(
            name="Mass-Ban",
            value=state(massban)
        )

        await interaction.response.send_message(
            embed=embed,
            ephemeral=True
        )


    @security.command(
        name="set",
        description="Enable or disable a security module"
    )
    @app_commands.checks.has_permissions(
        administrator=True
    )
    @app_commands.choices(
        module=[
            app_commands.Choice(
                name="Anti-Nuke",
                value="antinuke_enabled"
            ),
            app_commands.Choice(
                name="Anti-Raid",
                value="antiraid_enabled"
            ),
            app_commands.Choice(
                name="Anti-Spam",
                value="antispam_enabled"
            ),
            app_commands.Choice(
                name="Mass-Ban",
                value="massban_enabled"
            ),
        ]
    )
    @app_commands.choices(
        state=[
            app_commands.Choice(
                name="ON",
                value=1
            ),
            app_commands.Choice(
                name="OFF",
                value=0
            ),
        ]
    )
    async def set_module(
        self,
        interaction: discord.Interaction,
        module: app_commands.Choice[str],
        state: app_commands.Choice[int]
    ):

        await set_setting(
            interaction.guild.id,
            module.value,
            state.value
        )

        await interaction.response.send_message(
            f"✅ `{module.name}` → "
            f"`{'ON' if state.value else 'OFF'}`",
            ephemeral=True
        )


async def setup(bot):
    await bot.add_cog(
        SecurityStatus(bot)
    )
