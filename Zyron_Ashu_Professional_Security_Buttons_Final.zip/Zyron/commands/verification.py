import discord
from discord import app_commands
from discord.ext import commands

from security.protected_role import get_or_create_protected_role, protect_member
from database.protected import mark_protected
from core.security_log import security_log

class VerificationView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Verify", emoji="✅", style=discord.ButtonStyle.success, custom_id="zyron:verify")
    async def verify(self, interaction: discord.Interaction, button: discord.ui.Button):
        role = await get_or_create_protected_role(interaction.guild)
        if role is None:
            return await interaction.response.send_message(
                "❌ I cannot create/manage the `Zyron Protected` role. Put my role above the Protected role and grant Manage Roles.",
                ephemeral=True
            )
        if role >= interaction.guild.me.top_role:
            return await interaction.response.send_message(
                "❌ My highest role must be above `Zyron Protected`.",
                ephemeral=True
            )
        ok = await protect_member(interaction.user)
        if not ok:
            return await interaction.response.send_message("❌ Verification could not be completed.", ephemeral=True)
        await mark_protected(interaction.guild.id, interaction.user.id)
        await security_log(interaction.guild, "Member Verified", f"{interaction.user.mention} received `Zyron Protected`.")
        await interaction.response.send_message("✅ **Verification complete.** You are now protected by Zyron Security.", ephemeral=True)

class Verification(commands.GroupCog, group_name="verification", group_description="Zyron member verification"):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="setup", description="Create the Zyron verification panel")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setup_panel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        role = await get_or_create_protected_role(interaction.guild)
        if role is None:
            return await interaction.response.send_message("❌ I could not create the Protected role. Check Manage Roles and hierarchy.", ephemeral=True)
        await channel.send(
            embed=discord.Embed(
                title="🔐 Zyron Verification",
                description="Welcome! Click **Verify** below to complete verification and receive the `Zyron Protected` role.",
                color=discord.Color.blurple()
            ).set_footer(text="Zyron Security • Developed by - Ashu"),
            view=VerificationView()
        )
        await interaction.response.send_message(f"✅ Verification panel sent to {channel.mention}.", ephemeral=True)

    @app_commands.command(name="status", description="Check verification role status")
    async def status(self, interaction: discord.Interaction):
        role = discord.utils.get(interaction.guild.roles, name="Zyron Protected")
        await interaction.response.send_message(
            f"🛡️ `Zyron Protected`: {role.mention if role else 'Not created'}",
            ephemeral=True
        )

async def setup(bot):
    await bot.add_cog(Verification(bot))
