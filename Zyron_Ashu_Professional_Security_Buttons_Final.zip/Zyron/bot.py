import os
import logging
import discord

from discord.ext import commands


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)

logger = logging.getLogger("Zyron")


TOKEN = os.getenv("DISCORD_TOKEN")

if not TOKEN:
    try:
        from token_config import TOKEN as TOKEN_VALUE
        TOKEN = TOKEN_VALUE
    except ImportError:
        TOKEN = None

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is not set.")


intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.messages = True
intents.message_content = True


class ZyronBot(commands.Bot):

    def __init__(self):
        super().__init__(
            command_prefix="!",
            intents=intents,
            help_command=None
        )

    async def setup_hook(self):

        from core.database import init_database
        from database.protected import init_protected_db
        from database.feedback import init_feedback_db
        await init_database()
        await init_protected_db()
        await init_feedback_db()

        extensions = [
            "commands.help",
            "commands.whitelist",
            "commands.protection",
            "commands.security",
            "commands.security_admin",
            "commands.security_status",
            "commands.security_logs",
            "commands.security100",
            "commands.verification",
            "commands.feedback",
        ]

        for extension in extensions:
            try:
                await self.load_extension(extension)
                logger.info(
                    "Loaded extension: %s",
                    extension
                )
            except Exception:
                logger.exception(
                    "Failed to load extension: %s",
                    extension
                )

        try:
            synced = await self.tree.sync()

            logger.info(
                "Synced %d global slash commands",
                len(synced)
            )

        except Exception:
            logger.exception(
                "Failed to sync global slash commands"
            )

    async def on_ready(self):

        logger.info(
            "🛡️ Zyron online as %s",
            self.user
        )

        logger.info(
            "Connected to %d server(s)",
            len(self.guilds)
        )

    async def on_message(
        self,
        message: discord.Message
    ):

        if message.author.bot:
            return

        try:
            from security.antispam import antispam
            await antispam.handle_message(message)
        except Exception:
            logger.exception("Anti-Spam error")

        try:
            from security.antilink import antilink
            await antilink.handle_message(message)
        except Exception:
            logger.exception("Anti-Link error")

        await self.process_commands(
            message
        )

    async def on_member_join(
        self,
        member: discord.Member
    ):

        try:
            from security.antiraid import antiraid
            await antiraid.handle_join(member)
        except Exception:
            logger.exception("Anti-Raid error")

        if member.bot:
            try:
                from security.bot_guard import handle_bot_add
                await handle_bot_add(member)
            except Exception:
                logger.exception("Anti-Bot-Add error")

    async def on_member_update(
        self,
        before: discord.Member,
        after: discord.Member
    ):

        try:
            from security.member_role_guard import (
                handle_member_update
            )

            await handle_member_update(
                before,
                after
            )

        except Exception:
            logger.exception(
                "Member role guard error"
            )

    async def on_guild_channel_create(
        self,
        channel: discord.abc.GuildChannel
    ):

        try:
            logger.info(
                "Channel created: %s (%s) in %s",
                channel.name,
                channel.id,
                channel.guild.name
            )

            from security.channel_guard import (
                handle_channel_create
            )

            await handle_channel_create(
                channel
            )

        except Exception:
            logger.exception(
                "Channel create guard error"
            )

    async def on_guild_channel_delete(
        self,
        channel: discord.abc.GuildChannel
    ):

        try:
            from security.channel_guard import (
                handle_channel_delete
            )

            await handle_channel_delete(
                channel
            )

        except Exception:
            logger.exception(
                "Channel delete guard error"
            )

    async def on_guild_channel_update(
        self,
        before: discord.abc.GuildChannel,
        after: discord.abc.GuildChannel
    ):

        try:
            from security.channel_update_guard import (
                handle_channel_update
            )

            await handle_channel_update(
                before,
                after
            )

        except Exception:
            logger.exception(
                "Channel update guard error"
            )

    async def on_guild_role_create(
        self,
        role: discord.Role
    ):

        try:
            from security.role_guard import (
                handle_role_create
            )

            await handle_role_create(
                role
            )

        except Exception:
            logger.exception(
                "Role create guard error"
            )

    async def on_guild_role_delete(
        self,
        role: discord.Role
    ):

        try:
            from security.role_guard import (
                handle_role_delete
            )

            await handle_role_delete(
                role
            )

        except Exception:
            logger.exception(
                "Role delete guard error"
            )

    async def on_guild_role_update(
        self,
        before: discord.Role,
        after: discord.Role
    ):

        try:
            from security.permission_guard import (
                handle_role_update as handle_permission_update
            )
            from security.role_update_guard import (
                handle_role_update as handle_role_update_guard
            )

            await handle_permission_update(
                before,
                after
            )

            await handle_role_update_guard(
                before,
                after
            )

        except Exception:
            logger.exception(
                "Permission guard error"
            )

    async def on_guild_update(
        self,
        before: discord.Guild,
        after: discord.Guild
    ):

        try:
            from security.guild_guard import (
                handle_guild_update
            )

            await handle_guild_update(
                before,
                after
            )

        except ImportError:
            pass

        except Exception:
            logger.exception(
                "Guild update guard error"
            )

    async def on_webhooks_update(
        self,
        channel: discord.abc.GuildChannel
    ):

        try:
            from security.webhook_guard import (
                handle_webhook_create
            )

            await handle_webhook_create(
                channel
            )

        except Exception:
            logger.exception(
                "Webhook guard error"
            )

    async def on_guild_emojis_update(
        self,
        guild: discord.Guild,
        before,
        after
    ):

        try:
            from security.emoji_guard import handle_emoji_update

            await handle_emoji_update(
                guild,
                before,
                after
            )

        except ImportError:
            pass

        except Exception:
            logger.exception(
                "Emoji guard error"
            )

    async def on_invite_create(
        self,
        invite: discord.Invite
    ):

        try:
            from security.invite_guard import (
                handle_invite_create
            )

            await handle_invite_create(
                invite
            )

        except Exception:
            logger.exception(
                "Invite guard error"
            )

    async def on_guild_integrations_update(
        self,
        guild: discord.Guild
    ):

        try:
            from security.integration_guard import (
                handle_integration_update
            )

            await handle_integration_update(
                guild
            )

        except Exception:
            logger.exception(
                "Integration guard error"
            )

    async def fetch_member_executor(self, guild, target_id):
        try:
            from core.audit import get_executor
            return await get_executor(guild, discord.AuditLogAction.ban, target_id)
        except Exception:
            return None

    async def on_member_ban(
        self,
        guild: discord.Guild,
        user: discord.User
    ):

        try:
            from security.massban import massban_guard

            await massban_guard.handle_ban(
                guild,
                await self.fetch_member_executor(guild, user.id),
                user.id
            )

        except Exception:
            logger.exception(
                "Mass-ban guard error"
            )

    async def on_guild_role_create_log(
        self,
        role: discord.Role
    ):

        logger.info(
            "Role created: %s (%s) in %s",
            role.name,
            role.id,
            role.guild.name
        )

    async def on_member_remove(
        self,
        member: discord.Member
    ):

        try:
            from security.kick_guard import kick_guard

            await kick_guard.handle_kick(
                member
            )

        except Exception:
            logger.exception(
                "Kick guard error"
            )

    async def on_command_error(
        self,
        ctx: commands.Context,
        error: Exception
    ):

        if isinstance(
            error,
            commands.CommandNotFound
        ):
            return

        logger.error(
            "Command error: %s",
            error
        )


bot = ZyronBot()


if __name__ == "__main__":
    bot.run(TOKEN)
