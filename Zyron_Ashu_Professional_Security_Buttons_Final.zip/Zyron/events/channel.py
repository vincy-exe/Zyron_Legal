import discord

from security.channel_guard import handle_channel_delete


async def setup(bot):

    @bot.event
    async def on_guild_channel_delete(channel: discord.abc.GuildChannel):

        await handle_channel_delete(channel.guild)
