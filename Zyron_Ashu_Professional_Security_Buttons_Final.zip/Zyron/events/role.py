import discord

from security.role_guard import handle_role_delete


async def setup(bot):

    @bot.event
    async def on_guild_role_delete(role: discord.Role):

        await handle_role_delete(role.guild)
