ZYRON SECURITY BOT — FINAL BUILD

Features:
- Professional /help button dashboard
- Server Safety
- Logs Setup
- Whitelist
- Feedback
- Fixed 5-page All Commands navigation
- Verification panel
- Zyron Protected role after successful verification
- Protected members remain monitored; Protected is NOT a whitelist/immunity
- Explicit whitelist is the only trusted bypass for security guards (server owner is limited by Discord authority)
- Security/audit logging
- Anti-Nuke / Anti-Raid / Anti-Spam modules already included in the project

Verification setup:
1. Invite Zyron with the required permissions.
2. Put the Zyron bot role above `Zyron Protected`.
3. Run `/verification setup` and select the verification channel.
4. Members click Verify to receive `Zyron Protected`.

Feedback:
- Run `/feedback set-channel` to configure the feedback destination.
- The /help feedback buttons report Good / Bad / Suggestion / Bug Report.

Important Discord limitation:
A bot cannot override the server owner or Discord's role hierarchy. Automatic punishment only works when Zyron has the required permission and hierarchy.
