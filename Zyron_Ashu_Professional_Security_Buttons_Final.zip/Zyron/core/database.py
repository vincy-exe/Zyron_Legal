import aiosqlite

DB_PATH = "zyron.db"


async def init_database():

    async with aiosqlite.connect(DB_PATH) as db:

        await db.execute("""
            CREATE TABLE IF NOT EXISTS guild_settings (
                guild_id INTEGER PRIMARY KEY,

                security_enabled INTEGER DEFAULT 1,
                antinuke_enabled INTEGER DEFAULT 1,
                antiraid_enabled INTEGER DEFAULT 1,
                antispam_enabled INTEGER DEFAULT 1,
                massban_enabled INTEGER DEFAULT 1,

                log_channel_id INTEGER DEFAULT NULL
            )
        """)

        await db.execute("""
            CREATE TABLE IF NOT EXISTS whitelist (
                guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,

                PRIMARY KEY (
                    guild_id,
                    user_id
                )
            )
        """)

        await db.execute("""CREATE TABLE IF NOT EXISTS whitelist_entries (
            guild_id INTEGER NOT NULL, subject_type TEXT NOT NULL, subject_id INTEGER NOT NULL,
            action TEXT NOT NULL, PRIMARY KEY (guild_id, subject_type, subject_id, action))""")
        await db.commit()


async def ensure_guild(
    guild_id: int
):

    async with aiosqlite.connect(DB_PATH) as db:

        await db.execute(
            """
            INSERT OR IGNORE INTO guild_settings (
                guild_id,
                security_enabled,
                antinuke_enabled,
                antiraid_enabled,
                antispam_enabled,
                massban_enabled
            )
            VALUES (?, 1, 1, 1, 1, 1)
            """,
            (guild_id,)
        )

        await db.commit()
