import asyncio

import discord


async def get_executor(
    guild: discord.Guild,
    action: discord.AuditLogAction,
    target_id: int | None = None
):

    try:

        # Give Discord a moment to write the audit entry.
        await asyncio.sleep(1)

        now = discord.utils.utcnow()

        async for entry in guild.audit_logs(
            limit=10,
            action=action
        ):

            # Match the exact target.
            if target_id is not None:

                if getattr(
                    entry.target,
                    "id",
                    None
                ) != target_id:
                    continue

            # Ignore old audit-log entries.
            if entry.created_at is None:
                continue

            age = (
                now - entry.created_at
            ).total_seconds()

            if age > 15:
                continue

            return entry.user

    except (
        discord.Forbidden,
        discord.HTTPException
    ):
        return None

    return None
