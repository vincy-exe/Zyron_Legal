import discord
import aiosqlite

DB_PATH = "zyron.db"


async def security_log(
    guild: discord.Guild,
    title: str,
    description: str
):

    try:
        async with aiosqlite.connect(DB_PATH) as db:

            cursor = await db.execute(
                """
                SELECT log_channel_id
                FROM guild_settings
                WHERE guild_id = ?
                """,
                (guild.id,)
            )

            row = await cursor.fetchone()

        if not row or not row[0]:
            return

        channel = guild.get_channel(row[0])

        if channel is None:
            return

        embed = discord.Embed(
            title=f"🛡️ {title}",
            description=description,
            color=discord.Color.dark_red(),
            timestamp=discord.utils.utcnow()
        )

        embed.set_footer(
            text="Zyron Security"
        )

        await channel.send(
            embed=embed
        )

    except (
        discord.Forbidden,
        discord.HTTPException,
        aiosqlite.Error
    ):
        return
