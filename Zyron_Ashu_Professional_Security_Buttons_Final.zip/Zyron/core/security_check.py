from database.settings import get_settings


async def module_enabled(
    guild_id: int,
    module: str
) -> bool:

    settings = await get_settings(guild_id)

    if not settings["security_enabled"]:
        return False

    return bool(settings.get(module, False))
