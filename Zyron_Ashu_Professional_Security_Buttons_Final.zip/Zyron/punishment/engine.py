import discord

from core.logger import logger


async def ban_user(
    guild: discord.Guild,
    user: discord.Member,
    reason: str
):

    if guild.owner_id == user.id:
        logger.warning(
            "Blocked ban attempt against server owner: %s",
            user
        )
        return False

    if guild.me and user.id == guild.me.id:
        logger.warning(
            "Blocked ban attempt against Zyron"
        )
        return False

    try:

        logger.warning(
            "🚨 Zyron banning %s | %s",
            user,
            reason
        )

        await guild.ban(
            user,
            reason=f"Zyron Security: {reason}"
        )

        logger.warning(
            "✅ Successfully banned %s",
            user
        )

        return True

    except discord.Forbidden:

        logger.error(
            "❌ Cannot ban %s: missing permission or role hierarchy",
            user
        )

        return False

    except discord.HTTPException as error:

        logger.error(
            "❌ Discord ban failed for %s: %s",
            user,
            error
        )

        return False
