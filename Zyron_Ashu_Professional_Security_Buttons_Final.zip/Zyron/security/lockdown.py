import discord

from core.security_log import security_log


async def lockdown(
    guild: discord.Guild,
    reason: str = "Security lockdown"
):

    changed = 0

    for channel in guild.text_channels:

        try:

            overwrite = channel.overwrites_for(
                guild.default_role
            )

            overwrite.send_messages = False

            await channel.set_permissions(
                guild.default_role,
                overwrite=overwrite,
                reason=reason
            )

            changed += 1

        except (
            discord.Forbidden,
            discord.HTTPException
        ):
            continue

    await security_log(
        guild,
        "🔒 Server Lockdown",
        (
            f"Lockdown activated.\n"
            f"Reason: {reason}\n"
            f"Channels affected: `{changed}`"
        )
    )

    return changed
