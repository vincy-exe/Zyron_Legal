import json
import os

import discord


BACKUP_DIR = "backups"


async def create_backup(
    guild: discord.Guild
):

    os.makedirs(
        BACKUP_DIR,
        exist_ok=True
    )

    backup = {
        "guild_id": guild.id,
        "name": guild.name,
        "roles": [],
        "channels": []
    }

    for role in guild.roles:

        if role.is_default():
            continue

        backup["roles"].append({
            "id": role.id,
            "name": role.name,
            "permissions": role.permissions.value,
            "colour": role.colour.value,
            "hoist": role.hoist,
            "mentionable": role.mentionable
        })

    for channel in guild.channels:

        backup["channels"].append({
            "id": channel.id,
            "name": channel.name,
            "type": channel.type.name,
            "position": channel.position
        })

    path = os.path.join(
        BACKUP_DIR,
        f"{guild.id}.json"
    )

    with open(
        path,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            backup,
            file,
            indent=2,
            ensure_ascii=False
        )

    return path
