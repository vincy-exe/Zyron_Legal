import discord
import time

from collections import defaultdict, deque

from security.engine import can_execute_action
from punishment.engine import ban_user
from core.security_check import module_enabled
from core.security_log import security_log


class AntiSpam:

    def __init__(self):
        self.messages = defaultdict(deque)

    async def handle_message(
        self,
        message: discord.Message
    ):

        # Ignore DMs
        if not message.guild:
            return

        # Ignore bots
        if message.author.bot:
            return

        guild = message.guild
        user = message.author

        # Check Anti-Spam setting
        if not await module_enabled(
            guild.id,
            "antispam_enabled"
        ):
            return

        # Ignore trusted users
        if await can_execute_action(
            guild,
            user.id,
            "MESSAGE_SPAM"
        ):
            return

        now = time.monotonic()

        key = (
            guild.id,
            user.id
        )

        self.messages[key].append(now)

        # Keep only messages from the last 5 seconds
        while (
            self.messages[key]
            and now - self.messages[key][0] > 5
        ):
            self.messages[key].popleft()

        # 10 messages in 5 seconds = severe spam
        if len(self.messages[key]) >= 10:

            if isinstance(
                user,
                discord.Member
            ):

                success = await ban_user(
                    guild,
                    user,
                    "Severe message spam"
                )

                if success:

                    await security_log(
                        guild,
                        "Anti-Spam Action",
                        f"{user.mention} was banned for severe message spam."
                    )

            self.messages[key].clear()


antispam = AntiSpam()
