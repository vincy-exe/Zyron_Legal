import discord
import time

from datetime import timedelta
from collections import defaultdict, deque

from security.engine import can_execute_action
from core.security_check import module_enabled
from core.security_log import security_log


class AntiRaid:

    def __init__(self):
        self.joins = defaultdict(deque)

    async def handle_join(
        self,
        member: discord.Member
    ):

        if member.bot:
            return

        guild = member.guild

        # Check whether Anti-Raid is enabled
        if not await module_enabled(
            guild.id,
            "antiraid_enabled"
        ):
            return

        # Trusted users are ignored
        if await can_execute_action(
            guild,
            member.id,
            "RAID"
        ):
            return

        now = time.monotonic()

        self.joins[guild.id].append(now)

        # Keep only joins from the last 10 seconds
        while (
            self.joins[guild.id]
            and now - self.joins[guild.id][0] > 10
        ):
            self.joins[guild.id].popleft()

        # 15 joins within 10 seconds = raid threshold
        if len(self.joins[guild.id]) >= 15:

            try:

                await member.timeout(
                    timedelta(minutes=10),
                    reason="Zyron Anti-Raid"
                )

                await security_log(
                    guild,
                    "Anti-Raid Action",
                    f"{member.mention} was timed out because a raid threshold was detected."
                )

            except (
                discord.Forbidden,
                discord.HTTPException
            ):
                pass


antiraid = AntiRaid()
