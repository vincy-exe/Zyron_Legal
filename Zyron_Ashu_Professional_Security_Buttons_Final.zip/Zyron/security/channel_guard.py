import discord

from core.audit import get_executor
from security.engine import can_execute_action
from security.antinuke import antinuke


async def handle_channel_create(
    channel: discord.abc.GuildChannel
):

    executor = await get_executor(
        channel.guild,
        discord.AuditLogAction.channel_create,
        channel.id
    )

    if executor is None:
        return

    member = channel.guild.get_member(
        executor.id
    )

    if member is None:
        return

    await antinuke.handle_action(
        channel.guild,
        member,
        "channel_create",
        threshold=1
    )


async def handle_channel_delete(
    channel: discord.abc.GuildChannel
):

    executor = await get_executor(
        channel.guild,
        discord.AuditLogAction.channel_delete,
        channel.id
    )

    if executor is None:
        return

    member = channel.guild.get_member(
        executor.id
    )

    if member is None:
        return

    await antinuke.handle_action(
        channel.guild,
        member,
        "channel_delete",
        threshold=1
    )
