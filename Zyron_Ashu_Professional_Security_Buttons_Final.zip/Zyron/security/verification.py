import discord

from core.security_log import security_log


async def verify_member(
    member: discord.Member
):

    try:

        await member.edit(
            timed_out_until=None,
            reason="Zyron verification"
        )

        await security_log(
            member.guild,
            "Member Verified",
            f"{member.mention} was verified."
        )

        return True

    except (
        discord.Forbidden,
        discord.HTTPException
    ):
        return False
