import re
from collections import defaultdict, deque

import discord
from discord.ext import commands

from core.security_check import module_enabled
from security.engine import can_execute_action
from core.security_log import security_log

URL_RE = re.compile(r"https?://\S+|discord\.(gg|com/invite)/\S+", re.I)

class AntiLink:
    def __init__(self):
        self.links = defaultdict(deque)

    async def handle_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        if not await module_enabled(message.guild.id, "security_enabled"):
            return
        if await can_execute_action(message.guild, message.author.id, "LINK_SPAM"):
            return
        if not URL_RE.search(message.content or ""):
            return

        key = (message.guild.id, message.author.id)
        now = discord.utils.utcnow().timestamp()
        self.links[key].append(now)
        while self.links[key] and now - self.links[key][0] > 10:
            self.links[key].popleft()

        try:
            await message.delete()
        except (discord.Forbidden, discord.NotFound, discord.HTTPException):
            pass

        if len(self.links[key]) >= 3 and isinstance(message.author, discord.Member):
            try:
                await message.author.timeout(discord.utils.utcnow() + __import__('datetime').timedelta(minutes=10), reason="Zyron Anti-Link Spam")
            except (discord.Forbidden, discord.HTTPException):
                pass
            await security_log(
                message.guild,
                "Anti-Link Spam",
                f"{message.author.mention} triggered the link-spam protection threshold."
            )
            self.links[key].clear()

antilink = AntiLink()
