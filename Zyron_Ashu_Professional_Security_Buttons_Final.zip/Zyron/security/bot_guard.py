import discord

from core.audit import get_executor
from core.security_check import module_enabled
from core.security_log import security_log
from security.engine import can_execute_action


async def handle_bot_add(
    member: discord.Member
):

    guild = member.guild

    if not member.bot:
        return

    if not await module_enabled(
        guild.id,
        "antinuke_enabled"
    ):
        return

    executor = await get_executor(
        guild,
        discord.AuditLogAction.bot_add,
        member.id
    )

    if executor is None:
        return

    if executor.id == guild.owner_id:
        return

    if await can_execute_action(
        guild,
        executor.id,
        "BOT_ADD"
    ):
        return

    await security_log(
        guild,
        "Unauthorized Bot Added",
        (
            f"Bot: {member.mention}\n"
            f"Added by: {executor.mention}\n"
            f"User ID: `{executor.id}`"
        )
    )
