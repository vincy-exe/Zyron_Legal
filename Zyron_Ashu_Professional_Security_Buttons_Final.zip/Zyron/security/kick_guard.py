import discord
import time

from collections import defaultdict

from core.audit import get_executor
from core.security_check import module_enabled
from core.security_log import security_log
from security.engine import can_execute_action, is_target_protected
from punishment.engine import ban_user


class KickGuard:

    def __init__(self):
        self.actions = defaultdict(list)

    async def handle_kick(
        self,
        guild: discord.Guild,
        target: discord.User
    ):

        if not await module_enabled(
            guild.id,
            "massban_enabled"
        ):
            return

        executor = await get_executor(
            guild,
            discord.AuditLogAction.kick,
            target.id
        )

        if executor is None:
            return

        member = guild.get_member(
            executor.id
        )

        if member is None:
            return

        if executor.id == guild.owner_id:
            return

        if await can_execute_action(guild, executor.id, "KICK"):
            return

        if await is_target_protected(guild, target.id):
            success = await ban_user(guild, member, "Unauthorized kick of a Zyron Protected member")
            await security_log(guild, "Protected Member Attack Blocked", f"{member.mention} attempted to kick protected member `{target.id}`.")
            if success:
                await security_log(guild, "Unauthorized Executor Punished", f"{member.mention} was banned.")
            return

        now = time.monotonic()

        key = (
            guild.id,
            executor.id
        )

        self.actions[key].append(now)

        self.actions[key] = [
            timestamp
            for timestamp in self.actions[key]
            if now - timestamp <= 10
        ]

        if len(self.actions[key]) >= 5:

            success = await ban_user(
                guild,
                member,
                "Mass-kick activity detected"
            )

            if success:
                await security_log(
                    guild,
                    "Mass-Kick Protection",
                    f"{member.mention} triggered the mass-kick threshold."
                )

            self.actions[key].clear()


kick_guard = KickGuard()
