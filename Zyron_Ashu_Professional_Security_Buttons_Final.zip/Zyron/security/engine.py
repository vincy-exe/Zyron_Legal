import discord
from database.protected import is_protected_member, is_action_whitelisted

async def can_execute_action(guild: discord.Guild, user_id: int, action: str = "ALL") -> bool:
    return await is_action_whitelisted(guild, user_id, action)

async def is_target_protected(guild: discord.Guild, user_id: int) -> bool:
    if guild.owner_id == user_id:
        return True
    member=guild.get_member(user_id)
    if member is not None:
        from security.protected_role import is_protected
        if is_protected(member):
            return True
    return await is_protected_member(guild, user_id)
