import discord

from core.audit import get_executor
from core.security_check import module_enabled
from core.security_log import security_log
from security.engine import can_execute_action


async def handle_role_update(
    before: discord.Role,
    after: discord.Role
):

    if (
        before.name == after.name
        and before.permissions == after.permissions
        and before.color == after.color
        and before.hoist == after.hoist
        and before.mentionable == after.mentionable
    ):
        return

    guild = after.guild

    if not await module_enabled(
        guild.id,
        "antinuke_enabled"
    ):
        return

    executor = await get_executor(
        guild,
        discord.AuditLogAction.role_update,
        after.id
    )

    if executor is None:
        return

    if executor.id == guild.owner_id:
        return

    if await can_execute_action(
        guild,
        executor.id,
        "ROLE_CREATE"
    ):
        return

    await security_log(
        guild,
        "Role Update",
        (
            f"Role: {after.mention}\n"
            f"Changed by: {executor.mention}"
        )
    )
