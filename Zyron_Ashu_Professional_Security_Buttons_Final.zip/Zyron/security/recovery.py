import discord

from core.security_log import security_log


async def restore_channel_name(
    channel: discord.abc.GuildChannel,
    name: str
):

    try:

        await channel.edit(
            name=name,
            reason="Zyron security recovery"
        )

        await security_log(
            channel.guild,
            "Channel Recovery",
            f"Restored channel name to `{name}`."
        )

        return True

    except (
        discord.Forbidden,
        discord.HTTPException
    ):
        return False


async def restore_role_name(
    role: discord.Role,
    name: str
):

    try:

        await role.edit(
            name=name,
            reason="Zyron security recovery"
        )

        await security_log(
            role.guild,
            "Role Recovery",
            f"Restored role name to `{name}`."
        )

        return True

    except (
        discord.Forbidden,
        discord.HTTPException
    ):
        return False
