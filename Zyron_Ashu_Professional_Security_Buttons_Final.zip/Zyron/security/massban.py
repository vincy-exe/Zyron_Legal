import discord
import time

from collections import defaultdict

from security.engine import can_execute_action, is_target_protected
from core.security_check import module_enabled
from core.security_log import security_log
from punishment.engine import ban_user


class MassBanGuard:

    def __init__(self):
        self.actions = defaultdict(list)

    async def handle_ban(
        self,
        guild: discord.Guild,
        executor: discord.Member,
        target_id: int | None = None
    ):

        if executor is None:
            return

        # Check Mass-Ban protection setting
        if not await module_enabled(guild.id, "massban_enabled"):
            return

        # Never punish the server owner
        if executor.id == guild.owner_id:
            return

        # Ignore trusted / whitelisted users
        if await can_execute_action(guild, executor.id, "BAN"):
            return

        # A protected member being banned by a non-whitelisted executor is a high-confidence event.
        if target_id is not None and await is_target_protected(guild, target_id):
            success = await ban_user(guild, executor, "Unauthorized ban of a Zyron Protected member")
            await security_log(
                guild,
                "Protected Member Attack Blocked",
                f"{executor.mention} attempted to ban protected member `{target_id}`."
            )
            if success:
                await security_log(guild, "Unauthorized Executor Punished", f"{executor.mention} was banned.")
            return

        now = time.monotonic()

        key = (
            guild.id,
            executor.id
        )

        self.actions[key].append(now)

        # Keep only actions from the last 10 seconds
        self.actions[key] = [
            timestamp
            for timestamp in self.actions[key]
            if now - timestamp <= 10
        ]

        # 5 bans within 10 seconds = mass-ban threshold
        if len(self.actions[key]) >= 5:

            success = await ban_user(
                guild,
                executor,
                "Mass-ban activity detected"
            )

            if success:

                await security_log(
                    guild,
                    "Mass-Ban Protection",
                    f"{executor.mention} triggered the mass-ban protection threshold."
                )

            self.actions[key].clear()


massban_guard = MassBanGuard()
