import discord

from core.audit import get_executor
from core.security_check import module_enabled
from core.security_log import security_log
from security.engine import can_execute_action


async def handle_member_update(
    before: discord.Member,
    after: discord.Member
):

    if before.roles == after.roles:
        return

    guild = after.guild

    if not await module_enabled(
        guild.id,
        "antinuke_enabled"
    ):
        return

    executor = await get_executor(
        guild,
        discord.AuditLogAction.member_role_update,
        after.id
    )

    if executor is None:
        return

    if executor.id == guild.owner_id:
        return

    if await can_execute_action(
        guild,
        executor.id,
        "PERMISSION_CHANGE"
    ):
        return

    await security_log(
        guild,
        "Member Role Changed",
        (
            f"Member: {after.mention}\n"
            f"Changed by: {executor.mention}"
        )
    )
