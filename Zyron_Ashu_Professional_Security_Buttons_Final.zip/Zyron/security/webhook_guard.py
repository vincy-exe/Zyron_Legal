import discord

from core.audit import get_executor
from security.engine import can_execute_action
from punishment.engine import ban_user


async def handle_webhook_create(
    guild: discord.Guild
):

    executor = await get_executor(
        guild,
        discord.AuditLogAction.webhook_create
    )

    if executor is None:
        return

    if executor.id == guild.owner_id:
        return

    if await can_execute_action(
        guild,
        executor.id,
        "WEBHOOK_CREATE"
    ):
        return

    if isinstance(executor, discord.Member):

        await ban_user(
            guild,
            executor,
            "Unauthorized webhook creation"
        )
