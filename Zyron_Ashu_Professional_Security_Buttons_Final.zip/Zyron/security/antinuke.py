import time
from collections import defaultdict

import discord

from security.engine import can_execute_action
from core.security_check import module_enabled
from core.security_log import security_log
from punishment.engine import ban_user


class AntiNuke:

    def __init__(self):
        self.actions = defaultdict(list)

    async def handle_action(
        self,
        guild: discord.Guild,
        executor: discord.Member,
        action_name: str,
        threshold: int = 1,
        window: int = 10
    ):

        # Anti-Nuke enabled?
        if not await module_enabled(
            guild.id,
            "antinuke_enabled"
        ):
            return

        # Never punish server owner
        if executor.id == guild.owner_id:
            return

        # Never punish Zyron itself
        if guild.me and executor.id == guild.me.id:
            return

        # Check whether executor is trusted
        # Protected role is NOT executor immunity.
        if await can_execute_action(
            guild,
            executor.id,
            "ALL"
        ):
            return

        now = time.monotonic()

        key = (
            guild.id,
            executor.id,
            action_name
        )

        self.actions[key].append(now)

        # Keep only recent actions
        self.actions[key] = [
            timestamp
            for timestamp in self.actions[key]
            if now - timestamp <= window
        ]

        count = len(self.actions[key])

        # Direct punishment
        if count >= threshold:

            reason = (
                f"Unauthorized {action_name}"
            )

            success = await ban_user(
                guild,
                executor,
                reason
            )

            if success:

                try:
                    await security_log(
                        guild,
                        "🚨 Anti-Nuke Action",
                        (
                            f"**User:** {executor.mention}\n"
                            f"**Action:** `{action_name}`\n"
                            f"**Punishment:** 🔨 Ban\n"
                            f"**Reason:** `{reason}`"
                        )
                    )

                except Exception:
                    pass

            self.actions[key].clear()


antinuke = AntiNuke()
