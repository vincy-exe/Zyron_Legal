import aiosqlite

DB_PATH = "zyron.db"


DEFAULTS = {
    "security_enabled": 1,
    "antinuke_enabled": 1,
    "antiraid_enabled": 1,
    "antispam_enabled": 1,
    "massban_enabled": 1,
}


async def get_setting(
    guild_id: int,
    key: str
):

    if key not in DEFAULTS:
        return DEFAULTS.get(key, 0)

    async with aiosqlite.connect(DB_PATH) as db:

        cursor = await db.execute(
            f"SELECT {key} FROM guild_settings WHERE guild_id = ?",
            (guild_id,)
        )

        row = await cursor.fetchone()

    if row is None:
        return DEFAULTS[key]

    return row[0]


async def set_setting(
    guild_id: int,
    key: str,
    value: int
):

    if key not in DEFAULTS:
        raise ValueError("Invalid security setting")

    async with aiosqlite.connect(DB_PATH) as db:

        await db.execute(
            f"""
            UPDATE guild_settings
            SET {key} = ?
            WHERE guild_id = ?
            """,
            (value, guild_id)
        )

        await db.commit()
