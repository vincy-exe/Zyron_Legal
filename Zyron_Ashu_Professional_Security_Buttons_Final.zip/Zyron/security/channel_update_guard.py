import discord

from core.audit import get_executor
from core.security_check import module_enabled
from core.security_log import security_log
from security.engine import can_execute_action


async def handle_channel_update(
    before: discord.abc.GuildChannel,
    after: discord.abc.GuildChannel
):

    if (
        before.name == after.name
        and before.overwrites == after.overwrites
    ):
        return

    guild = after.guild

    if not await module_enabled(
        guild.id,
        "antinuke_enabled"
    ):
        return

    executor = await get_executor(
        guild,
        discord.AuditLogAction.channel_update,
        after.id
    )

    if executor is None:
        return

    if executor.id == guild.owner_id:
        return

    if await can_execute_action(
        guild,
        executor.id,
        "CHANNEL_CREATE"
    ):
        return

    await security_log(
        guild,
        "Channel Permission Update",
        (
            f"Channel: {after.mention}\n"
            f"Changed by: {executor.mention}"
        )
    )
