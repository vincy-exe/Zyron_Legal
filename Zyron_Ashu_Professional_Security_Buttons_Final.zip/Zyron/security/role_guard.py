import discord

from core.audit import get_executor
from security.antinuke import antinuke


async def handle_role_create(
    role: discord.Role
):

    executor = await get_executor(
        role.guild,
        discord.AuditLogAction.role_create,
        role.id
    )

    if executor is None:
        return

    member = role.guild.get_member(
        executor.id
    )

    if member is None:
        return

    await antinuke.handle_action(
        role.guild,
        member,
        "role_create",
        threshold=3
    )


async def handle_role_delete(
    role: discord.Role
):

    executor = await get_executor(
        role.guild,
        discord.AuditLogAction.role_delete,
        role.id
    )

    if executor is None:
        return

    member = role.guild.get_member(
        executor.id
    )

    if member is None:
        return

    await antinuke.handle_action(
        role.guild,
        member,
        "role_delete",
        threshold=3
    )
