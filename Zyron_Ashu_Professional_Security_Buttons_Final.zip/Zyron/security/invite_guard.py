import discord

from core.security_check import module_enabled
from core.security_log import security_log


async def handle_invite_create(
    invite: discord.Invite
):

    guild = invite.guild

    if guild is None:
        return

    if not await module_enabled(
        guild.id,
        "antinuke_enabled"
    ):
        return

    await security_log(
        guild,
        "Invite Created",
        (
            f"Invite `{invite.code}` was created.\n"
            f"Channel: {invite.channel.mention if invite.channel else 'Unknown'}"
        )
    )
