import discord

PROTECTED_ROLE_NAME = "Zyron Protected"


async def get_or_create_protected_role(
    guild: discord.Guild
):
    role = discord.utils.get(
        guild.roles,
        name=PROTECTED_ROLE_NAME
    )

    if role is None:
        try:
            role = await guild.create_role(
                name=PROTECTED_ROLE_NAME,
                reason="Zyron Security Protected Role"
            )
        except (
            discord.Forbidden,
            discord.HTTPException
        ):
            return None

    # Keep the role below Zyron's highest role
    me = guild.me

    if me is not None:
        try:
            if role < me.top_role:
                await role.edit(
                    position=max(
                        1,
                        me.top_role.position - 1
                    ),
                    reason="Zyron Protected role hierarchy"
                )
        except (
            discord.Forbidden,
            discord.HTTPException
        ):
            pass

    return role


async def protect_member(
    member: discord.Member
):
    role = await get_or_create_protected_role(
        member.guild
    )

    if role is None:
        return False

    if role not in member.roles:
        try:
            await member.add_roles(
                role,
                reason="Zyron Protected"
            )
        except (
            discord.Forbidden,
            discord.HTTPException
        ):
            return False

    return True


def is_protected(
    member: discord.Member
) -> bool:

    return any(
        role.name == PROTECTED_ROLE_NAME
        for role in member.roles
    )
