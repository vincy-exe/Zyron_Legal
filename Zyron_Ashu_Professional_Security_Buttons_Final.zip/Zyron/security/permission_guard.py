import discord

from core.audit import get_executor
from security.antinuke import antinuke


async def handle_role_update(
    before: discord.Role,
    after: discord.Role
):

    # Permission change nahi hua
    if before.permissions == after.permissions:
        return

    # Dangerous permissions
    dangerous_permissions = (
        "administrator",
        "manage_guild",
        "manage_roles",
        "manage_channels",
        "ban_members",
        "kick_members",
        "manage_webhooks",
    )

    # Check whether ANY dangerous permission was newly added
    dangerous_added = any(
        getattr(after.permissions, permission)
        and not getattr(before.permissions, permission)
        for permission in dangerous_permissions
    )

    # Koi dangerous permission add nahi hui
    if not dangerous_added:
        return

    # Audit log se executor find karo
    executor = await get_executor(
        after.guild,
        discord.AuditLogAction.role_update,
        after.id
    )

    if executor is None:
        return

    # Executor ka Member object
    member = after.guild.get_member(
        executor.id
    )

    if member is None:
        return

    # Anti-Nuke
    await antinuke.handle_action(
        after.guild,
        member,
        "dangerous_permission_change",
        threshold=1
    )
