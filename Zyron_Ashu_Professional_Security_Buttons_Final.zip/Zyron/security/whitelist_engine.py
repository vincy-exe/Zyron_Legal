import discord

from database.protected import is_whitelisted


async def is_trusted(
    guild: discord.Guild,
    user_id: int
):

    if user_id == guild.owner_id:
        return True

    return await is_whitelisted(
        guild.id,
        user_id
    )
