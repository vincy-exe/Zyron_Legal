import discord

from core.security_check import module_enabled
from core.security_log import security_log


async def handle_integration_update(
    guild: discord.Guild
):

    if not await module_enabled(
        guild.id,
        "antinuke_enabled"
    ):
        return

    await security_log(
        guild,
        "Integration Update",
        "A server integration update was detected."
    )
